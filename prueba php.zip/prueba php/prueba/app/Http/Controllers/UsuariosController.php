<?php
      namespace App\Http\Controllers;
      use Illuminate\Http\Request;
      use App\ Usuarios;
      class UsuariosController extends Controller {

       public function show() {
         $usuarios = Usuarios::all();
        return $usuarios;
        }

      public function  add(Request $request){



/*

array(8) { ["nombres"]=> string(6) "asasas"
["apellidos"]=> string(6) "asasas"
["email"]=> string(6) "asasas"
["telefono"]=> string(5) "assas"
["programa"]=> string(6) "Ingles"
["password"]=> string(6) "asasas"
["tipousuario"]=> string(10) "estudiante"
["estado"]=> string(1) "1" }
*/
        $usuarios= new Usuarios();
         $respuesta;
      $nombres=$request->input('nombres');
      $apellidos=$request->input('apellidos');
      $email=$request->input('email');
      $telefono=$request->input('telefono');
      $programa=$request->input('programa');
      $password=$request->input('password');
      $tipousuario=$request->input('tipousuario');
      $estado=$request->input('estado');
      $usuarios->nombres=$nombres;
      $usuarios->apellidos=$apellidos;
      $usuarios->email=$email;
      $usuarios->telefono=$telefono;
      $usuarios->programa=$programa;
      $usuarios->password=$password;
      $usuarios->tipousuario=$tipousuario;
      $usuarios->estado=$estado;
      if ($usuarios->save()) {

                     $respuesta = 'operacion  exitosa';
                  }
                  return $respuesta;
        }
public function showedit(Request $request){
     $id=$request->input('id');
     $usuarios = Usuarios::find($id);
     }
public function edit(Request $request){
        $id=$request->input('id');
      $nombres=$request->input('nombres');
$apellidos=$request->input('apellidos');
$email=$request->input('email');
$telefono=$request->input('telefono');
$programa=$request->input('programa');
$password=$request->input('password');
$tipousuario=$request->input('tipousuario');
$estado=$request->input('estado');
$usuarios = Usuarios::find($id);$usuarios->nombres=$nombres;
$usuarios->apellidos=$apellidos;
$usuarios->email=$email;
$usuarios->telefono=$telefono;
$usuarios->programa=$programa;
$usuarios->password=$password;
$usuarios->tipousuario=$tipousuario;
$usuarios->estado=$estado;
if ($usuarios->save()) {

               $respuesta = 'operacion  exitosa';
            } $respuesta;
        }
public function delete(Request $request){
     $id=$request->input('id');
     $usuarios = Usuarios::findOrFail($id);
     $usuarios->delete();

     }}
